// Type definitions for iview 3.1.0
// Project: https://github.com/iview/iview
// Definitions by: yangdan
// Definitions: https://github.com/yangdan8/iview.git
import iView from './iview';

export default iView;
export as namespace iView;

export * from './iview.components';